---
name: makeboldsolutions-design
description: Use this skill to generate well-branded interfaces and assets for Make Bold Solutions (fractional & interim CFO leadership consultancy), either for production or throwaway prototypes/mocks. Contains essential design guidelines, colors, type, fonts, assets, and UI kit components for prototyping.
user-invocable: true
---

# Make Bold Solutions — Design System

Read `readme.md` first — it is the full design guide (brand context, content
voice, visual foundations, iconography, and a file index). Then explore the other
files as needed.

## What's here
- `styles.css` — global entry point; link this one file to get all tokens + fonts.
- `tokens/` — CSS custom properties: colors, typography, spacing, effects, base.
- `assets/` — logos (the peak mark SVG + lockups) and webfonts.
- `guidelines/` — foundation specimen cards (Colors, Type, Spacing, Brand).
- `components/` — reusable React primitives (Button, Card, Badge, Eyebrow, Input),
  each with a `.d.ts` (props), `.prompt.md` (usage), and a card preview.
- `ui_kits/website/` — interactive marketing-website recreation built to spec.

## Brand in one breath
Confident financial leadership, made clear. **Rust `#982407`** + **ember `#C6620C`**
accents on warm **cream `#F8F6F2`**, ink `#1E1E1E` text. Display face **Be Vietnam
Pro** (extrabold, tight tracking); body **Inter Tight**. Sharp geometric peak mark,
modest radii, tight warm shadows, no-bounce motion. Voice is senior and calm —
"we" to "you", sentence case, no emoji, no hype. Signature move: letter-spaced
uppercase eyebrows.

## How to work
If creating visual artifacts (slides, mocks, throwaway prototypes), **copy the
assets you need out of `assets/`** and produce static HTML files for the user to
view — reference `styles.css` for tokens. If working on production code, copy the
assets and read the rules here to design as an expert in this brand.

If invoked with no other guidance, ask the user what they want to build, ask a few
focused questions, then act as an expert designer who outputs HTML artifacts _or_
production code, depending on the need.
