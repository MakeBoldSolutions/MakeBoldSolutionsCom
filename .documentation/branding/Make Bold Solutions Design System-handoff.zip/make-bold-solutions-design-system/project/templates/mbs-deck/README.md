# Make Bold Solutions Deck — template

A reusable 16:9 presentation **template** for Make Bold Solutions, built as a
Design Component (`MbsDeck.dc.html`) on the brand tokens. It ships populated with
the firm's **Fractional CFO** narrative (the 10-slide carousel from
makeboldsolutions.com/fractional-cfo.html) so it doubles as a finished deck and a
starting point for future ones.

## Files
- `MbsDeck.dc.html` — the deck (10 slides). Edit slide `<section>`s directly.
- `deck-stage.js` — slide shell: scaling, keyboard nav, thumbnail rail, print/PDF.
- `ds-base.js` — loads the design system's `styles.css` (fonts + tokens) and bundle.
- `MakeBoldSolutions-FractionalCFO.pptx` — editable PowerPoint export of the deck.

## Reusable slide layouts
Copy a `<section>` and swap its text to reuse any of these:
1. **Title** (cream) — eyebrow, big two-line display headline, subtitle, large peak
   watermark, logo lockup + slide counter.
2. **Content** (cream, 2-col) — eyebrow + headline + body on the left; a bullet
   list or a stack of bordered cards on the right.
3. **Stat** (dark) — eyebrow + headline + body, then a 3-up row of large ember
   figures with captions. Use for credentials / proof.
4. **Grid** (sunken) — eyebrow + headline + a 2×2 grid of service cards.
5. **Cards** (cream) — eyebrow + headline + a 3-column numbered card row (steps,
   options, tiers).
6. **Closing** (dark) — centered mark, eyebrow, display headline, CTA button.

## Conventions
- Canvas is **1920×1080**. Every slide repeats the brand color literals inline
  (rust `#982407`, ember `#C6620C` / `#E88F3D` on dark, ink `#1E1E1E`, cream
  `#F8F6F2`) — inline styles paint immediately and survive direct editing.
- Fonts: **Be Vietnam Pro** (display, 800) and **Inter Tight** (body), loaded via
  `ds-base.js` → `styles.css`.
- Each slide carries `data-label` (thumbnail rail) and `data-screen-label` (the
  "0X / 10" counter context). Footer: peak mark + MakeBold lockup, bottom-left;
  slide counter, bottom-right.
- No entrance animations — kept static so PowerPoint/PDF export and print are
  reliable (deck re-parenting cancels CSS animations mid-flight).

## Re-export to PowerPoint
Open the deck in the preview, then export with the deck-stage settings (1920×1080,
`resetTransformSelector: "deck-stage"`, `goTo(N)` navigation, Google-Font imports
for Be Vietnam Pro + Inter Tight).
