import * as React from "react";

/** Text field with label, hint and error. Calm, structured, ember focus ring. */
export interface InputProps {
  label?: string;
  hint?: string;
  error?: string;
  id?: string;
  type?: string;
  /** Render an input or a textarea. @default "input" */
  as?: "input" | "textarea";
  placeholder?: string;
  value?: string;
  defaultValue?: string;
  onChange?: (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => void;
  style?: React.CSSProperties;
}

export function Input(props: InputProps): JSX.Element;
