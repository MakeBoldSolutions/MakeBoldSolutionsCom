Text field with label, hint, and error states. Ember focus ring; supports input or textarea.

```jsx
import { Input } from "./Input";

<Input label="Work email" type="email" placeholder="you@company.com" />
<Input label="How can we help?" as="textarea" hint="A sentence or two is plenty." />
<Input label="Phone" error="Enter a valid number." />
```

Props: `label`, `hint`, `error`, `as` ("input"|"textarea"), plus native input props (`type`, `value`, `onChange`, `placeholder`). Error state recolors the border and message to critical.
