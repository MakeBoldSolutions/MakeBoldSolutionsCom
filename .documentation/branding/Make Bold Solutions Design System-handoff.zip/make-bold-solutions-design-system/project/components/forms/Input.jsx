import React from "react";

/**
 * Make Bold Solutions — Input
 * Text field with label, hint and error. Calm, structured, ember focus.
 */
export function Input({
  label,
  hint,
  error,
  id,
  type = "text",
  as = "input",
  style = {},
  ...rest
}) {
  const reactId = React.useId();
  const fieldId = id || reactId;
  const [focus, setFocus] = React.useState(false);
  const Tag = as;

  const field = {
    width: "100%",
    fontFamily: "var(--font-body)",
    fontSize: "var(--fs-base)",
    color: "var(--text-strong)",
    background: "var(--surface-card)",
    border: `1px solid ${error ? "var(--critical)" : focus ? "var(--accent)" : "var(--border-default)"}`,
    borderRadius: "var(--radius-md)",
    padding: as === "textarea" ? "12px 14px" : "11px 14px",
    outline: "none",
    boxShadow: focus ? "var(--ring-focus)" : "none",
    transition: "border-color var(--dur-fast) var(--ease-standard), box-shadow var(--dur-fast) var(--ease-standard)",
    boxSizing: "border-box",
    minHeight: as === "textarea" ? "96px" : "auto",
    resize: as === "textarea" ? "vertical" : "none",
    ...style,
  };

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: "6px" }}>
      {label && (
        <label htmlFor={fieldId} style={{ fontSize: "var(--fs-sm)", fontWeight: "var(--fw-semibold)", color: "var(--text-body)" }}>
          {label}
        </label>
      )}
      <Tag
        id={fieldId}
        type={as === "input" ? type : undefined}
        style={field}
        onFocus={() => setFocus(true)}
        onBlur={() => setFocus(false)}
        {...rest}
      />
      {(error || hint) && (
        <span style={{ fontSize: "var(--fs-sm)", color: error ? "var(--critical)" : "var(--text-muted)" }}>
          {error || hint}
        </span>
      )}
    </div>
  );
}
