The brand's signature letter-spaced uppercase label, in ember. Place above a heading to set context.

```jsx
import { Eyebrow } from "./Eyebrow";

<Eyebrow>Fractional CFO Leadership</Eyebrow>
<h2>Clarity over complexity.</h2>
```

Props: `color` (accent/brand/muted/onDark), `as`. Use sparingly — one per section. Never apply letter-spacing this wide to running text.
