Compact status or category label in muted, finance-grade tones.

```jsx
import { Badge } from "./Badge";

<Badge tone="brand">Fractional</Badge>
<Badge tone="positive">Engaged</Badge>
```

Tones: neutral, brand, accent, positive, caution, critical, info. Keep labels one or two words. Tones are intentionally desaturated — never candy-bright.
