Surface container for grouped content — feature cards, service tiles, stats, pull-outs. White on cream, hairline border, restrained shadow.

```jsx
import { Card } from "./Card";

<Card interactive accent padding="lg">
  <h3>Interim CFO</h3>
  <p>Steady financial leadership through a transition.</p>
</Card>
```

Props: `padding` (none/sm/md/lg/xl), `interactive` (lift + deepen shadow on hover), `accent` (3px rust top rule), `as`. Keep corners modest — never fully rounded.
