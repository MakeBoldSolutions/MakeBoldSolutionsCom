Confident, geometric brand button — use for all primary and secondary actions (CTAs, form submits, nav actions). Modest radius, no-bounce hover/press.

```jsx
import { Button } from "./Button";

<Button variant="primary" size="lg" onClick={book}>Book a consult</Button>
<Button variant="secondary">Our services</Button>
<Button variant="ghost" iconRight={<ArrowRight />}>Learn more</Button>
```

**Variants:** `primary` (rust, the default CTA), `accent` (ember, secondary emphasis), `secondary` (rust outline on transparent), `ghost` (text-only), `dark` (ink surface).
**Sizes:** `sm` / `md` / `lg`. Props: `iconLeft`, `iconRight`, `fullWidth`, `disabled`.
Hover darkens one step; press nudges down 1px — never scale-bounce. Keep labels short and verb-led ("Book a consult", "Get started").
