# Website UI Kit — Make Bold Solutions

A high-fidelity recreation of the Make Bold Solutions **marketing website** — the
firm's primary digital surface. Built entirely from the design-system components
(`Button`, `Card`, `Badge`, `Eyebrow`, `Input`) on the brand tokens.

> ⚠️ No Figma or site source code was provided, but the **live site
> (makeboldsolutions.com) was reviewed** and this kit matches its real content,
> services, and structure on the brand tokens — an independent rebuild, not the
> site's own code. Imagery uses the same Unsplash photography the live site uses.

## Run
Open `index.html`. It loads React + Babel + `_ds_bundle.js`, aliases the namespace
to `window.MBS`, then composes the section files.

## Screens / sections
- `SiteHeader.jsx` — sticky nav with the peak mark, wordmark, links, CTA button.
- `Hero.jsx` — headline, value prop, stat row, and a dark "monthly close" summary
  card (the product is financial clarity, so the hero visual is a report).
- `Services.jsx` — six-service grid of interactive `Card`s with `Badge` tags.
- `ValueStrip.jsx` — dark brand moment presenting the three core values.
- `ContactCTA.jsx` — working contact form (`Input` + `Button`, fake submit) plus
  the real contact details, and `SiteFooter`.

## Interactions
- Nav links + hero buttons smooth-scroll to the relevant section.
- Contact form validates lightly and shows a thank-you confirmation on submit.
- Cards lift on hover; buttons darken on hover and nudge on press.

## Notes
Sections write to `window.<Name>` so `index.html` can compose them across separate
Babel scripts. They read components from `window.MBS`. Icons would use Lucide
(see root readme); this kit keeps to the peak mark + type for now.
