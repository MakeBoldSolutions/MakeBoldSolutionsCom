/* Make Bold Solutions — "How We Help" services grid (real services) */
function Services() {
  const { Card, Eyebrow, Badge } = window.MBS;
  const services = [
    ["Fractional CFO", "Cash flow clarity, budgeting and forecasting you can act on, audit preparation, and strategic financial planning — senior-level leadership at the scope and pace your business requires.",
      ["Cash Flow Management", "Budgeting & Forecasting", "Audit Preparation", "Financial Reporting"]],
    ["Business Optimization", "From bookkeeping cleanup to building a close rhythm to getting your financial systems right — we help you build a foundation for confident decision-making.",
      ["Books Cleanup & Close Rhythm", "Process Improvement", "ERP & Systems Support", "Growth Planning"]],
    ["Nonprofit Governance", "Board treasurer services, financial governance, and compliance support — the same rigor we bring to every client, applied to organizations doing important community work.",
      ["Board Treasurer Services", "Financial Governance", "Grant & Fund Management", "Compliance Support"]],
    ["Fractional Corporate Controller", "Full-cycle accounting oversight, month-end close, reporting, and financial controls — the discipline of a dedicated controller, scaled to your engagement.",
      ["Month-End Close Management", "Financial Controls & Compliance", "Accounting Oversight", "Internal Reporting"]],
    ["Strategic Tax Planning", "Proactive tax strategy to minimize your liability and position your business for long-term financial health — not just at filing season.",
      ["Tax Strategy & Planning", "Entity Structure Optimization", "Deduction & Credit Maximization", "Year-Round Tax Advisory"]],
    ["Tax Preparation", "Accurate, thorough tax preparation for businesses, sole proprietors, and nonprofits — filed correctly and on time.",
      ["Business Tax Returns", "Sole Proprietor Filing", "Nonprofit Tax Compliance", "Multi-State Filing"]],
  ];
  return (
    <section style={{ background: "var(--surface-sunken)", padding: "var(--section-y) 0" }}>
      <div style={{ maxWidth: "var(--container-max)", margin: "0 auto", padding: "0 var(--gutter)" }}>
        <div style={{ maxWidth: "60ch" }}>
          <Eyebrow>How we help</Eyebrow>
          <h2 style={{ fontSize: "clamp(2rem,3.5vw,3rem)", margin: "14px 0 0", letterSpacing: "-0.02em" }}>
            Expertise and partnership, on your terms.
          </h2>
          <p style={{ fontSize: "var(--fs-lg)", color: "var(--text-muted)", marginTop: 16 }}>
            Whether you need cash flow clarity, a budget you can actually use, or
            someone to sit on your nonprofit board — we bring the expertise and do
            the work alongside you.
          </p>
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 20, marginTop: 44 }}>
          {services.map(([title, body, items]) => (
            <Card key={title} interactive accent style={{ display: "flex", flexDirection: "column" }}>
              <h3 style={{ fontSize: 20, margin: "0 0 8px" }}>{title}</h3>
              <p style={{ color: "var(--text-muted)", fontSize: 14.5, lineHeight: 1.55, margin: 0 }}>{body}</p>
              <ul style={{ listStyle: "none", padding: 0, margin: "16px 0 0", display: "flex", flexWrap: "wrap", gap: 6 }}>
                {items.map((it) => <li key={it}><Badge tone="neutral">{it}</Badge></li>)}
              </ul>
              <a href="#" onClick={(e) => e.preventDefault()} style={{ marginTop: 16, fontSize: 14, fontWeight: 600, color: "var(--text-link)" }}>Explore service →</a>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
window.Services = Services;
