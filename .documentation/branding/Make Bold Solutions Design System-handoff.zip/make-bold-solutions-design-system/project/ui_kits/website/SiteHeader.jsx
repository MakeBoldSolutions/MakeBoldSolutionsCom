/* Make Bold Solutions — site header / nav */
function SiteHeader({ onNav, active }) {
  const links = ["Services", "Fractional CFO", "Our Firm"];
  return (
    <header style={{
      position: "sticky", top: 0, zIndex: 20,
      background: "color-mix(in srgb, var(--surface-page) 88%, transparent)",
      backdropFilter: "blur(10px)",
      borderBottom: "1px solid var(--border-subtle)",
    }}>
      <div style={{
        maxWidth: "var(--container-max)", margin: "0 auto",
        padding: "0 var(--gutter)", height: 72,
        display: "flex", alignItems: "center", justifyContent: "space-between",
      }}>
        <a href="#" onClick={(e) => { e.preventDefault(); onNav("Home"); }}
           style={{ display: "flex", alignItems: "center", gap: 12, textDecoration: "none" }}>
          <svg viewBox="0 0 412 208" style={{ width: 38, height: "auto" }}>
            <path fill="#982407" d="M287.64,207.95H0L236.35,24.05l51.3,183.9Z"/>
            <path fill="#1E1E1E" d="M412,207.95H103.29L368.03,0l43.97,207.95Z"/>
          </svg>
          <span style={{ fontFamily: "var(--font-display)", fontWeight: 800, fontSize: 20, color: "var(--ink-900)", letterSpacing: "-0.02em" }}>
            Make<span style={{ color: "var(--brand)" }}>Bold</span>
          </span>
        </a>
        <nav style={{ display: "flex", alignItems: "center", gap: 4 }}>
          {links.map((l) => (
            <a key={l} href="#" onClick={(e) => { e.preventDefault(); onNav(l); }}
               style={{
                 padding: "8px 14px", fontSize: 15, fontWeight: 500,
                 color: active === l ? "var(--brand)" : "var(--text-body)",
                 textDecoration: "none", borderRadius: "var(--radius-sm)",
               }}>
              {l}
            </a>
          ))}
          <div style={{ marginLeft: 8 }}>
            <window.MBS.Button size="sm" variant="primary" onClick={() => onNav("Contact")}>
              Get in touch →
            </window.MBS.Button>
          </div>
        </nav>
      </div>
    </header>
  );
}
window.SiteHeader = SiteHeader;
