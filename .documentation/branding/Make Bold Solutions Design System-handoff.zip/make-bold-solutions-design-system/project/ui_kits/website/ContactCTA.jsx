/* Make Bold Solutions — contact section with working form + footer */
function ContactCTA() {
  const { Card, Eyebrow, Input, Button } = window.MBS;
  const [sent, setSent] = React.useState(false);
  return (
    <section id="contact" style={{ background: "var(--surface-page)", padding: "var(--section-y) 0" }}>
      <div style={{
        maxWidth: "var(--container-max)", margin: "0 auto", padding: "0 var(--gutter)",
        display: "grid", gridTemplateColumns: "1fr 1fr", gap: "clamp(2rem,5vw,5rem)", alignItems: "center",
      }}>
        <div>
          <Eyebrow>Get in touch</Eyebrow>
          <h2 style={{ fontSize: "clamp(2rem,3.5vw,3rem)", margin: "14px 0 0", letterSpacing: "-0.02em" }}>
            Ready to take the next step?
          </h2>
          <p style={{ fontSize: "var(--fs-lg)", color: "var(--text-muted)", marginTop: 16, maxWidth: "44ch" }}>
            Whether you're a growing business, a sole proprietor, or a nonprofit —
            let's have a conversation about how we can help. No obligation, no pressure.
          </p>
          <div style={{ marginTop: 28, display: "flex", flexDirection: "column", gap: 10, fontSize: 15 }}>
            <a href="mailto:lesley.hazleton@makeboldsolutions.com" style={{ color: "var(--text-link)", fontWeight: 500 }}>lesley.hazleton@makeboldsolutions.com</a>
            <span style={{ color: "var(--text-body)" }}>Wichita, Kansas — serving businesses across the region</span>
            <a href="https://www.linkedin.com/in/lesleyhazleton" style={{ color: "var(--text-muted)" }}>linkedin.com/in/lesleyhazleton</a>
          </div>
        </div>
        <Card padding="xl" style={{ boxShadow: "var(--shadow-lg)" }}>
          {sent ? (
            <div style={{ textAlign: "center", padding: "28px 8px" }}>
              <div style={{ fontFamily: "var(--font-display)", fontWeight: 800, fontSize: 24, color: "var(--brand)" }}>Thank you.</div>
              <p style={{ color: "var(--text-muted)", marginTop: 8 }}>We've received your note and will be in touch shortly.</p>
              <div style={{ marginTop: 18 }}>
                <Button variant="secondary" size="sm" onClick={() => setSent(false)}>Send another</Button>
              </div>
            </div>
          ) : (
            <form onSubmit={(e) => { e.preventDefault(); setSent(true); }} style={{ display: "flex", flexDirection: "column", gap: 16 }}>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14 }}>
                <Input label="Name" placeholder="Jane Founder" required />
                <Input label="Company" placeholder="Acme Inc." />
              </div>
              <Input label="Work email" type="email" placeholder="you@company.com" required />
              <Input label="How can we help?" as="textarea" placeholder="A sentence or two about your situation." />
              <Button type="submit" variant="primary" size="lg" fullWidth>Send message</Button>
            </form>
          )}
        </Card>
      </div>
    </section>
  );
}
window.ContactCTA = ContactCTA;

function SiteFooter() {
  return (
    <footer style={{ background: "var(--surface-dark-2)", color: "var(--ink-300)", padding: "48px 0 40px" }}>
      <div style={{
        maxWidth: "var(--container-max)", margin: "0 auto", padding: "0 var(--gutter)",
        display: "grid", gridTemplateColumns: "1.4fr 1fr", gap: 32, alignItems: "start",
      }}>
        <div>
          <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
            <svg viewBox="0 0 412 208" style={{ width: 34 }}>
              <path fill="var(--ember-400)" d="M287.64,207.95H0L236.35,24.05l51.3,183.9Z"/>
              <path fill="var(--cream)" d="M412,207.95H103.29L368.03,0l43.97,207.95Z"/>
            </svg>
            <span style={{ fontFamily: "var(--font-display)", fontWeight: 800, fontSize: 18, color: "var(--cream)" }}>
              Make<span style={{ color: "var(--ember-400)" }}>Bold</span>
              <span style={{ marginLeft: 8, fontFamily: "var(--font-body)", fontWeight: 600, fontSize: 11, letterSpacing: "0.4em", textTransform: "uppercase", color: "var(--ink-400)" }}>Solutions</span>
            </span>
          </div>
          <p style={{ color: "var(--ink-300)", fontSize: 14, maxWidth: "40ch", marginTop: 16, lineHeight: 1.6 }}>
            Strategic financial leadership for small and midsize businesses, sole
            proprietors, and nonprofits. Wichita, Kansas.
          </p>
        </div>
        <div style={{ textAlign: "right" }}>
          <div style={{ fontSize: 11, fontWeight: 600, letterSpacing: "0.16em", textTransform: "uppercase", color: "var(--ink-400)" }}>Our technical division</div>
          <a href="https://makeboldspark.com" style={{ display: "inline-block", marginTop: 8, fontFamily: "var(--font-display)", fontWeight: 700, fontSize: 18, color: "var(--ember-300)" }}>Make Bold Spark ↗</a>
          <div style={{ fontSize: 13, color: "var(--ink-400)", marginTop: 20 }}>
            © 2026 Make Bold Solutions. All rights reserved.
          </div>
        </div>
      </div>
    </footer>
  );
}
window.SiteFooter = SiteFooter;
