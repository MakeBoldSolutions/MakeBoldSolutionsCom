/* Make Bold Solutions — "Why Choose Us" dark strip + signature quote */
function ValueStrip() {
  const { Eyebrow } = window.MBS;
  const reasons = [
    ["Direct senior-level access", "No junior associates, no hand-offs. You get direct access to a seasoned, award-winning CPA who personally handles your finances and knows your business."],
    ["Built for businesses others overlook", "Most firms pass over small businesses and sole proprietors. We exist specifically to serve you — the same expertise Fortune 500s get, on your terms and budget."],
    ["Outcomes, not billable hours", "We focus on results you can see: cash flow clarity, a budget you can use, books you can trust, and a financial plan that actually helps you decide."],
  ];
  return (
    <section style={{ background: "var(--surface-dark)", color: "var(--cream)", padding: "var(--section-y) 0" }}>
      <div style={{ maxWidth: "var(--container-max)", margin: "0 auto", padding: "0 var(--gutter)" }}>
        <Eyebrow color="onDark">Why choose us</Eyebrow>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 40, marginTop: 36 }}>
          {reasons.map(([t, b], i) => (
            <div key={t}>
              <div style={{ fontFamily: "var(--font-display)", fontWeight: 800, fontSize: 38, color: "var(--ember-400)", lineHeight: 1 }}>
                0{i + 1}
              </div>
              <h3 style={{ color: "var(--cream)", fontSize: 20, margin: "16px 0 8px" }}>{t}</h3>
              <p style={{ color: "var(--ink-300)", fontSize: 15, lineHeight: 1.6 }}>{b}</p>
            </div>
          ))}
        </div>
        <blockquote style={{
          margin: "56px 0 0", paddingTop: 40, borderTop: "1px solid var(--ink-700)",
          fontFamily: "var(--font-display)", fontWeight: 800, fontSize: "clamp(1.75rem,3.2vw,2.75rem)",
          letterSpacing: "-0.02em", color: "var(--cream)", textAlign: "center", lineHeight: 1.2,
        }}>
          <span style={{ color: "var(--ember-400)" }}>“</span>Every business deserves a great CFO.<span style={{ color: "var(--ember-400)" }}>”</span>
        </blockquote>
      </div>
    </section>
  );
}
window.ValueStrip = ValueStrip;
