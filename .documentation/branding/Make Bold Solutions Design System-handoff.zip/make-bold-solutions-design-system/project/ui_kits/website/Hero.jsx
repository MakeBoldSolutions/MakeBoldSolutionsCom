/* Make Bold Solutions — homepage hero ("Big Firm Expertise. Small Firm Heart.") */
function Hero({ onNav }) {
  const { Eyebrow, Button } = window.MBS;
  const stats = [
    ["30+", "Years Experience"],
    ["CPA", "Licensed & Certified"],
    ["2023", "CFO of the Year"],
    ["PwC", "Alumni"],
  ];
  return (
    <section style={{ background: "var(--surface-page)", overflow: "hidden" }}>
      <div style={{
        maxWidth: "var(--container-max)", margin: "0 auto",
        padding: "clamp(3.5rem,7vw,6rem) var(--gutter)",
        display: "grid", gridTemplateColumns: "1.05fr 0.95fr", gap: "clamp(2rem,5vw,4.5rem)",
        alignItems: "center",
      }}>
        <div>
          <Eyebrow>Fractional CFO &amp; Financial Leadership</Eyebrow>
          <h1 style={{ fontSize: "clamp(2.6rem,4.6vw,4rem)", lineHeight: 1.04, letterSpacing: "-0.03em", margin: "18px 0 0" }}>
            Big firm expertise.<br /><span style={{ color: "var(--brand)" }}>Small firm heart.</span>
          </h1>
          <p style={{ fontSize: "var(--fs-xl)", color: "var(--text-muted)", maxWidth: "48ch", margin: "22px 0 0", lineHeight: 1.55 }}>
            Make Bold Solutions delivers senior-level financial leadership to growing
            businesses, sole proprietors, and nonprofits. Fractional by design —
            experienced CFO guidance and hands-on partnership, engaged at the scope
            and pace your organization needs.
          </p>
          <p style={{ fontSize: 15, color: "var(--text-body)", margin: "20px 0 0", fontWeight: 500 }}>
            Lesley Hazleton, CPA — <span style={{ color: "var(--accent-strong)" }}>Wichita Business Journal CFO of the Year, 2023</span>
          </p>
          <div style={{ display: "flex", gap: 14, marginTop: 30, flexWrap: "wrap" }}>
            <Button size="lg" variant="primary" onClick={() => onNav("Contact")}>Get in touch</Button>
            <Button size="lg" variant="secondary" onClick={() => onNav("Services")}>Get a cash flow snapshot</Button>
          </div>
        </div>
        <div style={{ position: "relative" }}>
          <div style={{
            borderRadius: "var(--radius-xl)", overflow: "hidden",
            boxShadow: "var(--shadow-xl)", aspectRatio: "4 / 5", background: "var(--ink-100)",
          }}>
            <img
              src="https://images.unsplash.com/photo-1553877522-43269d4ea984?ixlib=rb-4.0.3&auto=format&fit=crop&w=1100&q=80"
              alt="Small business financial consultation"
              style={{ width: "100%", height: "100%", objectFit: "cover" }}
            />
          </div>
          <svg viewBox="0 0 412 208" style={{ position: "absolute", left: -30, bottom: -28, width: 110, zIndex: -1 }}>
            <path fill="var(--rust-100)" d="M287.64,207.95H0L236.35,24.05l51.3,183.9Z"/>
            <path fill="var(--ink-100)" d="M412,207.95H103.29L368.03,0l43.97,207.95Z"/>
          </svg>
        </div>
      </div>
      <div style={{ borderTop: "1px solid var(--border-subtle)", background: "var(--surface-card)" }}>
        <div style={{
          maxWidth: "var(--container-max)", margin: "0 auto", padding: "28px var(--gutter)",
          display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 24,
        }}>
          {stats.map(([n, l]) => (
            <div key={l} style={{ textAlign: "center" }}>
              <div style={{ fontFamily: "var(--font-display)", fontWeight: 800, fontSize: 32, color: "var(--brand)", lineHeight: 1 }}>{n}</div>
              <div style={{ fontSize: 13, color: "var(--text-muted)", marginTop: 6, letterSpacing: "0.04em" }}>{l}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
window.Hero = Hero;
